export class Lecturer {}
