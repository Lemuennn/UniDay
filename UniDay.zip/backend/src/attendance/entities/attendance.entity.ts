export class Attendance {}
